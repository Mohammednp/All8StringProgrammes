package string;

public class CountSpecialCharacters {

	public static void main(String[] args) {
		String str="@#$%^HelloWorld";
		System.out.println("Given String: "+str);
		int special=0;
		
		for(int i=0; i<=str.length()-1; i++) {
			char ch = str.charAt(i);
			if(ch>='A'&&ch<='Z') {
			}else if(ch>='a'&&ch<='z') {
			}else {
				special++;
			}
	}
		System.out.println("Special Characters: "+special);
}
}
