package string;

public class RepeatedlyOccuring {

	public static void main(String[] args) {
		String str="ineuron";
		char[] arr1 = str.toCharArray();
		for(int i=0; i<=str.length()-1; i++) {
			for(int j=i+1; j<=str.length()-1; j++) {
				if(arr1[i]==arr1[j]) {
					System.out.print(arr1[j]);
					break;
				}
			}
		}
	}

}
