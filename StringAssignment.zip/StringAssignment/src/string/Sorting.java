package string;

import java.util.Arrays;

public class Sorting {

	public static void main(String[] args) {
		String str="FEDCBA";
		System.out.println("Given String: "+str);
		char[] charArray = str.toCharArray();
		Arrays.sort(charArray);
		System.out.println("After Sorting: "+new String(charArray));
	}

}
