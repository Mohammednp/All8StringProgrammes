package string;

public class CountVowelsandConsonants {

	public static void main(String[] args) {
		String s1="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String str = s1.toLowerCase();
		
		int vcount=0, ccount=0;
		
		for(int i=0; i<=str.length()-1; i++) {
			char ch = str.charAt(i);
			System.out.print(ch);
			if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u') {
				vcount++;
			}else if(ch>='a'&&ch<='z') {
				ccount++;
			}
		}
			System.out.println();
			System.out.println("Vowels: "+vcount);
			System.out.println("Consonants: "+ccount);
	}

}
