package string;

public class ReverseThinkTwice {

	public static void main(String[] args) {
		String s1="Think Twice";
		String s2 = s1.toLowerCase();
		String[] s3 = s2.split("\s");
		String reverse="";
		for(String sw: s3) {
			StringBuilder sb=new StringBuilder(sw);
			sb.reverse();
			reverse+=sb.toString()+" ";
		}
			System.out.println(reverse.trim());
}
	
}
